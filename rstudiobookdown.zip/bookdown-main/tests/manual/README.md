# Manual tests

This folder contains Rmd files useful for visual inspecteion of some features
