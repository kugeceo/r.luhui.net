The source documents for the bookdown.org homepage has been moved to https://github.com/rstudio/bookdown.org.
